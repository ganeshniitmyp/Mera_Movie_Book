var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser'); //parses information from POST


//Any requests to this controller must pass through this 'use' function
//Copy and pasted from method-override
router.use(bodyParser.urlencoded({ extended: true }))


var mongoose = require('mongoose');

var dbHost = 'mongodb://localhost:27017/test';
mongoose.connect(dbHost);

var seatingSchema = mongoose.Schema({
seatno: String
  
     });

var Seating = mongoose.model('Seating', seatingSchema, 'seating');



router.post('/seating', function(req, res){
  console.log(req.body);
  var seatno = req.body.seatno;
    
    var seating = new Seating({
    seatno : seatno
    });

  seating.save(function(err, docs){
    if ( err ) throw err;
    console.log("Seat failed");
    res.json(docs);
  });

  });








// catch 404 and forward to error handler
router.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});


module.exports = router;