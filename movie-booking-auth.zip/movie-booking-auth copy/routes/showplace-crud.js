
var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser'); //parses information from POST
router.use(bodyParser.urlencoded({ extended: true }));


var mongoose = require('mongoose');


// var dbHost = 'mongodb://localhost:27017/test';
// mongoose.connect(dbHost);



var showPlaceSchema = mongoose.Schema({
    City:String,
    showId:String,
    Name:String,
    showTime: String
 });

//therator Schhema

var ShowPlace = mongoose.model('ShowPlace', showPlaceSchema, 'showPlace');



//Master
  router.get('/showPlace', function (req, res) {
    console.log("REACHED city GET FUNCTION ON SERVER");
    ShowPlace.find({}, function (err, docs) {
         res.json(docs);         
    });
});

  router.get('/showPlace/:id', function (req, res) {
    console.log("REACHED GET ID FUNCTION ON SERVER");
    ShowPlace.find({_id: req.params.id}, function (err, docs) {
         res.json(docs);
         
    });
});

router.post('/showPlace', function(req, res){
  console.log(req.body);
  var city=req.body.City;
  var id = req.body.showId;
  var name=req.body.Name;
  var showtime=req.body.showTime;
  var showPlace = new ShowPlace({
    City:city,
    showId:id,
    Name:name,
    showTime :showtime
      
  });

  showPlace.save(function(err, docs){
    if ( err ) throw err;
    console.log("Book Saved Successfully");
    res.json(docs);
  });

  })

router.delete('/showPlace/:id', function(req, res){
   console.log("REACHED Delete FUNCTION ON SERVER");
      ShowPlace.remove({_id:req.params.id}, function(err, docs){
        res.json(docs);
    });
})

router.put('/showPlace/:id', function(req, res){
    console.log("REACHED PUT");
    console.log(req.body);
    ShowPlace.findOneAndUpdate({_id:req.params.id}, req.body, function (err, data) {
      res.json(data);
    });
})


  module.exports = router;