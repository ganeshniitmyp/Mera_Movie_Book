var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser'); //parses information from POST


//Any requests to this controller must pass through this 'use' function
//Copy and pasted from method-override
router.use(bodyParser.urlencoded({ extended: true }))


var mongoose = require('mongoose');
//var dbHost = 'mongodb://localhost:27017/test';
//mongoose.connect(dbHost);

var bookingSchema = mongoose.Schema({
id: String,
  City: String,
  Name:String,
  showTime:String,
    Title:String,
  not:String,
  price:String,
  
  amount:String
  
     });

var Booking = mongoose.model('Booking', bookingSchema, 'booking');

router.get('/booking', function (req, res) {
    console.log("REACHED GET FUNCTION ON SERVER");
    Booking.find({}, function (err, docs) {
         res.json(docs);

    });
});

router.get('/booking/:id', function (req, res) {
    console.log("REACHED GET ID FUNCTION ON SERVER");
     Booking.find({id: req.params.id}, function (err, docs) {
         res.json(docs);

    });
});


router.post('/booking', function(req, res){
  console.log(req.body);
  var id = req.body.id;
  var city = req.body.City;
  var name=req.body.Name;
  var time = req.body.showTime;
  var mname = req.body.Title;
  var not = req.body.not;
  var price = req.body.price;

  var amount=req.body.amount;
    
    var booking = new Booking({
    id : id,
  City:city,
  Name:name,
  showTime:time,
  Title:mname,
  not:not,
  price:price,

  amount:amount
    });

  booking.save(function(err, docs){
    if ( err ) throw err;
    console.log("Book failed");
    res.json(docs);
  });

  });


router.delete('/booking/:id',function(req,res){
  console.log('REACHED delete FUNCTION ON SERVER');
  console.log(req.params.id);
  Booking.remove({id:req.params.id},function(err,docs)
  {
res.json(docs);
  });
})






// catch 404 and forward to error handler
router.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});


module.exports = router;