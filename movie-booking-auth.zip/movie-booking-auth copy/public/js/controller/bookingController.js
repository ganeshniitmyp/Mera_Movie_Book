'use strict';

module.exports = function($scope,$rootScope, $http,$location) {

  $scope.now=$rootScope.nowDetails;
        console.log($scope.now);
    
  console.log($rootScope.name);
  
  var settings = {
               rows: 5,
               cols: 15,
               rowCssPrefix: 'row-',
               colCssPrefix: 'col-',
               seatWidth: 35,
               seatHeight: 35,
               seatCss: 'seat',
               selectedSeatCss: 'selectedSeat',
               selectingSeatCss: 'selectingSeat'
           };


           var init = function (reservedSeat) {
                var str = [], seatNo, className;
                for (var i = 0; i < settings.rows; i++) {
                    for (var j = 0; j < settings.cols; j++) {
                        seatNo = (i + j * settings.rows + 1);
                        className = settings.seatCss + ' ' + settings.rowCssPrefix + i.toString() + ' ' + settings.colCssPrefix + j.toString();
                        if ($.isArray(reservedSeat) && $.inArray(seatNo, reservedSeat) != -1) {
                            className += ' ' + settings.selectedSeatCss;
                        }
                        str.push('<li class="' + className + '"' +
                                  'style="top:' + (i * settings.seatHeight).toString() + 'px;left:' + (j * settings.seatWidth).toString() + 'px">' +
                                  '<a title="' + seatNo + '">' + seatNo + '</a>' +
                                  '</li>');
                    }
                }
                $('#place').html(str.join(''));
            };
            //case I: Show from starting
            //init();
 
            //Case II: If already booked
            var bookedSeats = [5, 10, 25];
            init(bookedSeats);  




$('.' + settings.seatCss).click(function () {
if ($(this).hasClass(settings.selectedSeatCss)){
    alert('This seat is already reserved');
}
else{
    $(this).toggleClass(settings.selectingSeatCss);
    }
});
 
$('#btnShow').click(function () {
    var str = [];
    $.each($('#place li.' + settings.selectedSeatCss + ' a, #place li.'+ settings.selectingSeatCss + ' a'), function (index, value) {
        str.push($(this).attr('title'));
    });
    alert(str.join(','));
})
 

$('#btnShowNew').click(function () {
    var str = [], item;
    $.each($('#place li.' + settings.selectingSeatCss + ' a'), function (index, value) {
        item = $(this).attr('title');                   
        str.push(item);                   
    });
    alert(str.join(','));
    //it is used to calculate how many seats are allocated
    alert(str.length);
    $scope.count=str.length;
    $scope.seat=str;

    seatingInfo();
})


/*var refreshseating = function () {
      $http.get('/sea/sea').success(function (response) {
          console.log('READ IS SUCCESSFUL');
          $scope.seatList = response;
          $scope.seat = "";

          
      });
  };
*/
  


//refreshseating();




var seatingInfo = function () {
console.log($scope.seat);
$http.post('/seating/seating',$scope.seat).success(function (response) {
console.log(response);
console.log("CREATE IS SUCCESSFULLY");
//refreshseating();  
                        // $route.reload();
 });
};







           // init(bookedSeats);




  //console.log(MovieList.getMovies());


/*


(function(){
    
    var cityDetails = function($http){
      
      var getCity = function(cityname){
            return $http.get('/city/city')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getCity
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('cityDetails', cityDetails);
    
}());


   (function(){
    
    var showDetails = function($http){
      
      var getshow = function(showtime){
            return $http.get('/show/show')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getshow
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('showDetails', showDetails);
    
}());
   (function(){

    var showPlace1 = function($http){

      var getPlace = function(place){
            return $http.get('/showPlace/showPlace')
                        .then(function(response){
                           return response.data;
                        });
      };

      return {
          get: getPlace
      };

    };

    var module = angular.module('movieApp');
    module.factory('showPlace1', showPlace1);

}());


(function(){
    
    var getMovieInfo = function($http){
      
      var getshowinfo = function(showinfo){
            return $http.get('/movieinfo/movieinfo')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getshowinfo
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('getMovieInfo', getMovieInfo);
    
}());









  //City Methods Starts
  var refresh=function()
  {
        $http.get('/city/city').success(function(response){
            console.log('Admin curd');
            $scope.cityData=response;
            $scope.city="";
        });
  };
  refresh();


$scope.addCity=function()
  {
            console.log('addCity');
            $http.post('/city/city',$scope.city).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refresh();
            });
        };
  




//show Timing Methods starts
var refreshsh=function()
  {
        $http.get('/show/show').success(function(response){
            console.log('show curd');
            $scope.showData=response;
            $scope.show="";
        });
  };
  refreshsh();



 $scope.addShow=function()
  {
            console.log('addShow');
            $http.post('/show/show',$scope.show).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refreshsh();
            });
        };
 






//Show place Methods Starts
var refreshsp=function()
  {
        $http.get('/showPlace/showPlace').success(function(response){
            console.log('showPlace curd');
            $scope.showPlace=response;
            $scope.shp="";
        });
  };
  refreshsp();

$scope.addShowPlace=function()
  {
            console.log('addShow');
            $http.post('/showPlace/showPlace',$scope.shp).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refreshsp();
            });
        };



 var refreshnow = function () {
                            $http.get('/movieinfo/movieinfo').success(function (response) {
                                console.log('READ IS SUCCESSFUL');
                                $scope.nowlist = response;
                                $scope.now = "";
                            });
                        };

                    refreshnow();



$scope.addMovieInfo = function () {
                              console.log($scope.now);
                              $http.post('/movieinfo/movieinfo',$scope.now).success(function (response) {
                                  console.log(response);
                                  console.log("CREATE IS SUCCESSFUL");
                                  refreshnow();
                              });
                          };









var movieObj={};

$scope.getData = function(){
  console.log('Hi Welcome')
  $http.get('http://www.omdbapi.com/?t='+$scope.movieObj.Title+'&y='+$scope.movieObj.Year+'&plot=short&r=json',{data:"aishu"}).success(function (response) {
      console.log(response);
     // var movieObj={};
      for(var key in response){
      if(key=='Title'|| key=='Year' || key== 'Language' || key== 'Poster' || key== 'Genre' || key== 'Director' || key== 'Actors')
      {
      movieObj[key] = response[key];
      }
     
    console.log(movieObj);

      }
           refresh5();
  });
}













 var refresh5 = function () {
                            $http.get('/movie/movie').success(function (response) {
                                console.log('READ IS SUCCESSFUL');
                                $scope.movieObj = response;
                                $scope.moviess = "";
                            });
                        };

                    refresh5();

$scope.addMovie = function () {
                              console.log(movieObj);
                              $http.post('/movie/movie',movieObj).success(function (response) {
                                  console.log(response);
                                  console.log("CREATE IS SUCCESSFUL");
                                  refresh5();
                              });
                          };

*/
//

var refreshbook = function () {
      $http.get('/booking/booking').success(function (response) {
          console.log('READ IS SUCCESSFUL');
          $scope.bookingList = response;
          $scope.booking = "";
      });
  };

  


refreshbook();

/*it goes to no of seats:
  $scope.seating = $rootScope.seatingDetails;
  console.log($scope.seating);

*/


$scope.bookMovieInfo = function () {
console.log($scope.booking);
$http.post('/booking/booking',$scope.booking).success(function (response) {
console.log(response);
console.log("CREATE IS SUCCESSFUL");
  $rootScope.bookingDetails = $scope.booking;

            $location.path('/confirm');
                        // $route.reload();
          

});
};

/*

$scope.removebook=function(id)
{
  console.log(id);
  $http.delete('/booking/booking'+id_id).success(function(response)
  {
    console.log(response);
    console.log("DELETED SUCCESSFULLY");
    refreshbook();
  });
};
*/
/*



  var refresh = function () {
        $http.get('/movie/movie').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.contactlist = response;
            $scope.contact = "";
        });
    };

    refresh();

    $scope.addMovie = function () {
        console.log($scope.contact);
        $http.post('/movie/movie', $scope.contact).success(function (response) {
            console.log(response);
            console.log("CREATE IS SUCCESSFUL");
            refresh();
        });
    };

    $scope.removeMovie = function (id) {
        console.log(id);
        $http.delete('/movie/movie/' + id._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresh();
        });
    };

    $scope.editMovie = function (id) {
         $http.get('/movie/movie/' + id._id).success(function (response) {
            $scope.contact = response[0];
        });
    };

    $scope.updateMovie = function () {
        console.log("REACHED UPDATE");
        console.log($scope.contact._id);
        $http.put('/movie/movie/' + $scope.contact._id, $scope.contact).success(function (response) {
            console.log(response);
            refresh();
        })
    }*/


}

