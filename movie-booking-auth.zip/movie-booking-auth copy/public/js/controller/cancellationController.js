'use strict';

module.exports = function($scope, $rootScope, $http, TodoService) {
  $scope.cancellation = 'cancellation';
  $scope.booking = "";
  $scope.id =""

   $scope.getCancellation = function(){
             $http.delete('/booking/booking/' + $scope.id)
                        .success(function(response){
                           console.log(response);
                            $scope.booking = response;
                            alert(" TICKET CANCELLATION SUCESSFULLY ");
                        });
      };

};