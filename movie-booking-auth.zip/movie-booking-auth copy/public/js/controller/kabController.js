



'use strict';

module.exports=function($scope,$rootScope,$http,$location) {

/*         $scope.no=$rootScope.nows;
         console.log($scope.no);

*/














  //add in kab controller
                           $scope.editMovieInfokab= function (City) {
                            console.log('reached controller');
                      $http.get('/movieinfo/movieinfo/' + City.City).success(function (response) {
                                 console.log('reached crud');
                                  $scope.now = response[0];
                                  console.log('hello')

                              });
                          };
}