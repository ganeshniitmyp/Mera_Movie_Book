'use strict';

module.exports=function($scope,$rootScope,$http,$location)
{
	/*$scope.now=$$rootScope.nowDet;
	console.log($scope.now);
	*/
	//$scope.cancellation='cancellation';
	//$scope.no=$rootScope.nowDet;
	$scope.booking = $rootScope.bookingDetails;

	console.log($scope.booking);
}