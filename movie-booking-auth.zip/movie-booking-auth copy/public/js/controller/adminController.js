
'use strict';

module.exports = function($scope,$rootScope, $http,$location)  {
  $scope.admin = 'admin';

  $(document).ready(function() {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
});
  (function(){
    
    var cityDetails = function($http){
      
      var getCity = function(cityname){
            return $http.get('/city/city')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getCity
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('cityDetails', cityDetails);
    
}());


   (function(){
    
    var showDetails = function($http){
      
      var getshow = function(showtime){
            return $http.get('/show/show')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getshow
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('showDetails', showDetails);
    
}());
   (function(){

    var showPlace1 = function($http){

      var getPlace = function(place){
            return $http.get('/showPlace/showPlace')
                        .then(function(response){
                           return response.data;
                        });
      };

      return {
          get: getPlace
      };

    };

    var module = angular.module('movieApp');
    module.factory('showPlace1', showPlace1);

}());
   //1
  //City Methods Starts
  var refresh=function()
  {
        $http.get('/city/city').success(function(response){
            console.log('Admin curd');
            $scope.cityData=response;
            $scope.city="";
        });
  };
  refresh();
  $scope.addCity=function()
  {
            console.log('addCity');
            $http.post('/city/city',$scope.city).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refresh();
            });
        };
        $scope.removeCity=function(id){
                console.log('removeCity');
                $http.delete('/city/city/'+id._id).success(function(response){
                console.log(response);
                console.log("Deleted successfull");
                refresh();     
                });
        };
        $scope.editCity=function(id)
        {
                console.log('Edit city');
                $http.get('/city/city/'+id._id).success(function(response){
                    $scope.city=response[0];
                });
        };
        $scope.updateCity = function (id) {
        console.log("REACHED UPDATE");
        console.log($scope.city._id);
        $http.put('/city/city/' + $scope.city._id, $scope.city).success(function (response) {
            console.log(response);
            refresh();
        })
    };
//City methods Ends

//3
//show Timing Methods starts
var refreshsh=function()
  {
        $http.get('/show/show').success(function(response){
            console.log('show curd');
            $scope.showData=response;
            $scope.show="";
        });
  };
  refreshsh();
  $scope.addShow=function()
  {
            console.log('addShow');
            $http.post('/show/show',$scope.show).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refreshsh();
            });
        };
        $scope.removeShow=function(id){
                console.log('removeShow');
                $http.delete('/show/show/'+id._id).success(function(response){
                console.log(response);
                console.log("Deleted successfull");
                refreshsh();     
                });
        };
        $scope.editShow=function(id)
        {
                console.log('Edit show');
                $http.get('/show/show/'+id._id).success(function(response){
                    $scope.show=response[0];
                });
        };
        $scope.updateShow = function (id) {
        console.log("REACHED UPDATE");
        console.log($scope.show._id);
        $http.put('/show/show/' + $scope.show._id, $scope.show).success(function (response) {
            console.log(response);
            refreshsh();
        })
    };
//Show timing Methods Ends

//2
//Show place Methods Starts
var refreshsp=function()
  {
        $http.get('/showPlace/showPlace').success(function(response){
            console.log('showPlace curd');
            $scope.showPlace=response;
            $scope.shp="";
        });
  };
  refreshsp();
  $scope.addShowPlace=function()
  {
            console.log('addShow');
            $http.post('/showPlace/showPlace',$scope.shp).success(function(response){
                console.log(response);
                console.log("Added successfull");
                refreshsp();
            });
        };
        $scope.removeShowPlace=function(id){
                console.log('removeShow');
                $http.delete('/showPlace/showPlace/'+id._id).success(function(response){
                console.log(response);
                console.log("Deleted successfull");
                refreshsp();     
                });
        };
        $scope.editShowPlace=function(id)
        {
                console.log('Edit show');
                $http.get('/showPlace/showPlace/'+id._id).success(function(response){
                    $scope.shp=response[0];
                });
        };
        $scope.updateShowPlace = function (id) {
        console.log("REACHED UPDATE");
        console.log($scope.shp._id);
        $http.put('/showPlace/showPlace/' + $scope.shp._id, $scope.shp).success(function (response) {
            console.log(response);
            refreshsp();
        });
    };
    //Show places Methods Ends

    //Offers Method Starts

    //offers end here
    //movie curd begins
//Retriving data from omdb  database

//5
var movieObj={};

$scope.getData = function(){
  console.log('Hi Welcome')
  $http.get('http://www.omdbapi.com/?t='+$scope.movieObj.Title+'&y='+$scope.movieObj.Year+'&plot=short&r=json',{data:"aishu"}).success(function (response) {
      console.log(response);
     // var movieObj={};
      for(var key in response){
      if(key=='Title'|| key=='Year' || key== 'Language' || key== 'Poster' || key== 'Genre' || key== 'Director' || key== 'Actors')
      {
      movieObj[key] = response[key];
      }
     
    console.log(movieObj);

      }
           refresh5();
  });
}



                        var refresh5 = function () {
                            $http.get('/movie/movie').success(function (response) {
                                console.log('READ IS SUCCESSFUL');
                                $scope.movieObj = response;
                                $scope.moviess = "";
                            });
                        };

                    refresh5();




                          $scope.addMovie = function () {
                              console.log(movieObj);
                              $http.post('/movie/movie',movieObj).success(function (response) {
                                  console.log(response);
                                  console.log("CREATE IS SUCCESSFUL");
                                  refresh5();
                              });
                          };

//6
(function(){
    
    var getMovieInfo = function($http){
      
      var getshowinfo = function(showinfo){
            return $http.get('/movieinfo/movieinfo')
                        .then(function(response){
                           return response.data; 
                        });
      };
  
      return {
          get: getshowinfo
      };
        
    };
    
    var module = angular.module('movieApp');
    module.factory('getMovieInfo', getMovieInfo);
    
}());






                          $scope.removeMovie = function (id) {
                              console.log(id);
                              $http.delete('/movie/movie/' + id._id).success(function (response) {
                                  console.log(response);
                                  console.log('DELETED SUCCESSFULLY');
                                  refresh5();
                              });
                          };

                          $scope.editMovie= function (id) {
                               $http.get('/movie/movie/' + id._id).success(function (response) {
                                  $scope.movieObj = response[0];
                              });
                          };

                          $scope.updateMovie = function () {
                              console.log("REACHED UPDATE");
                              console.log($scope.movieObj._id);
                              $http.put('/movie/movie/' + $scope.movieObj._id, $scope.movieObj).success(function (response) {
                                  console.log(response);
                                  refresh5();
                              })
                          };




    //movie curds ends


    var refreshnow = function () {
                            $http.get('/movieinfo/movieinfo').success(function (response) {
                                console.log('READ IS SUCCESSFUL');
                                $scope.nowlist = response;
                                $scope.now = "";
                            });
                        };

                    refreshnow();




$scope.addMovieInfo = function () {
                              console.log($scope.now);
                              $http.post('/movieinfo/movieinfo',$scope.now).success(function (response) {
                                  console.log(response);
                                  console.log("CREATE IS SUCCESSFUL");
    
                                   //$rootScope.nows = $scope.now;
                                  refreshnow();
                              });
                          };







                          $scope.removeMovieInfo = function (id) {
                              console.log(id);
                              $http.delete('/movieinfo/movieinfo/' + id._id).success(function (response) {
                                  console.log(response);
                                  console.log('DELETED SUCCESSFULLY');
                                  refreshnow();
                              });
                          };

                          $scope.editMovieInfo= function (id) {
                               $http.get('/movieinfo/movieinfo/' + id._id).success(function (response) {
                                  $scope.now = response[0];

                              });
                          };


//kab controller in kab html

$scope.editMovieInfokab= function (City) {
                            console.log('reached controller');
                      $http.get('/movieinfo/movieinfo/' + City.City).success(function (response) {
                                 console.log('reached crud');
                                  $scope.now = response[0];
                                  console.log('hello')

                              });
                          };

//book button in kab html
       $scope.editMovieIn= function (id) {
                               $http.get('/movieinfo/movieinfo/' + id._id).success(function (response) {
                                  $scope.now = response[0];
                                  $rootScope.nowDetails = $scope.now;
            $location.path('/booking');
  

                              });
                          };


                          $scope.updateMovieIfno = function () {
                              console.log("REACHED UPDATE");
                              console.log($scope.now._id);
                              $http.put('/movieinfo/movieinfo/' + $scope.now._id, $scope.now).success(function (response) {
                                  console.log(response);
                                  refreshnow();
                              })
                          };



};
  

       
