'use strict';


var angular = require('angular');
require('angular-route');
window.$ = window.jQuery = require('jquery');
require('bootstrap');
require('angularjs-dropdown-multiselect');
require('../css/app.scss');

var app = angular.module('movieApp', [ 'ngRoute' ]);


require('./controller');
require('./service');

app.config(function($routeProvider) {

  $routeProvider.when('/', {
    templateUrl: 'views/home.html',
     controller: 'HomeController',
    access: {restricted: false}
  })
  .when('/login', {
      templateUrl: 'views/login.html',
      controller: 'LoginController',
      access: {restricted: false}
    })
    .when('/logout', {
      controller: 'LogoutController',
      access: {restricted: true}
    })
    .when('/register', {
      templateUrl: 'views/register.html',
      controller: 'RegisterController',
      access: {restricted: false}
    })
  .when('/booking', {
    templateUrl: 'views/booking.html',
    controller: 'BookingController',
  })
  .when('/cancellation', {
    templateUrl: 'views/cancellation.html',
    controller: 'CancellationController',
  })
  .when('/admin', {
    templateUrl: 'views/admin.html',
    controller: 'AdminController',
    //
    access: {restricted: true}
  })

.when('/confirm', {
    templateUrl: 'views/confirm.html',
    controller: 'ConfirmController',
    //
    access: {restricted: false}
  })


.when('/search', {
    templateUrl: 'views/search.html',
    controller: 'SearchController',
  })



.when('/tamil', {
    templateUrl: 'views/tamil.html',
    //controller:'TamilController',
  })


.when('/english', {
    templateUrl: 'views/english.html',
    
  })




.when('/hindi', {
    templateUrl: 'views/hindi.html',
    
  })

//seat availabilty
 .when('/seat availablity', {
    templateUrl: 'views/seat availablity.html',
    controller: 'SeatAvailblity',
  })

// kabali movie
.when('/kab',
{
templateUrl: 'views/kab.html',
    controller: 'AdminController',
})
  
  .otherwise({
    redirectTo: '/',
  });
});

app.run(function ($rootScope, $location, $route, AuthService) {
  $rootScope.$on('$routeChangeStart',
    function (event, next, current) {
      AuthService.getUserStatus()
      .then(function(){
        if (next.access.restricted && !AuthService.isLoggedIn()){
          $location.path('/login');
          $route.reload();
        }
      });
  });
});
